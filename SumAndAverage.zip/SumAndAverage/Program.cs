﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SumAndAverage
{
    class Program
    {
        static void Main(string[] args)
        {
            SequenceOfNumbers.AddNumbers();
            Console.WriteLine("Sum: " + SequenceOfNumbers.Sum);
            Console.WriteLine("Average: " + SequenceOfNumbers.Average);
        }
    }
}
